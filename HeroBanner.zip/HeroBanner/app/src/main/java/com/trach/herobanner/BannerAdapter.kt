/**
 * Created by laivantrach1190@gmail.com
 * Copyright (c) 2019 . All rights reserved.
 */
package com.trach.herobanner

import com.trach.herobannerlib.adapters.HeroBannerAdapter

class BannerAdapter: HeroBannerAdapter<Banner>() {

}