/**
 * Created by laivantrach1190@gmail.com
 * Copyright (c) 2019 . All rights reserved.
 */
package com.trach.herobannerlib

import android.content.Context
import android.os.Build
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.viewpager2.widget.ViewPager2
import com.trach.herobannerlib.config.Config
import java.util.*
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import androidx.viewpager2.widget.ViewPager2.*
import com.trach.herobannerlib.HeroBanner.IndicatorPageChangeListener
import com.trach.herobannerlib.adapters.HeroBannerAdapter
import com.trach.herobannerlib.services.ImageLoadingService
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import com.trach.herobannerlib.indicators.SlideIndicatorsGroup

class HeroBanner<T> : FrameLayout {

    private lateinit var config: Config
    private lateinit var viewPager2: ViewPager2
    private lateinit var timer: Timer

    private var adapter: HeroBannerAdapter<T>? = null
    protected var isInfinite = true
    protected var isAutoScroll = false

    //AutoScroll
    private var interval = 5000L
    private var previousPosition = 0
    private var currentPagePosition = 0

    //For Indicator
    private var previousScrollState = SCROLL_STATE_IDLE
    private var scrollState = SCROLL_STATE_IDLE
    private var isToTheRight = true
    private var isIndicatorSmart = false
    private var slideIndicatorsGroup: SlideIndicatorsGroup? = null

    constructor(context: Context) : super(context) {
        initViews(null)
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        initViews(attrs)
    }

    constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(context, attrs, defStyle) {
        initViews(attrs)
    }

    private fun initViews(attrs: AttributeSet?) {
        val typedArray = context.obtainStyledAttributes(attrs, R.styleable.HeroBanner)
        if (typedArray != null) {
            config = Config.Builder()
                .autoScroll(typedArray.getBoolean(R.styleable.HeroBanner_is_auto_scroll, false))
                .indicatorSize(typedArray.getDimensionPixelSize(R.styleable.HeroBanner_indicator_size, 12))
                .showIndicator(typedArray.getBoolean(R.styleable.HeroBanner_is_show_indicator, false))
                .interval(typedArray.getInt(R.styleable.HeroBanner_interval, 1500).toLong())
                .build(context)
            typedArray.recycle()
        } else {
            config = Config.Builder().build(context)
        }
        setupViews()
    }

    private fun setupViews() {
        timer = Timer()
        viewPager2 = ViewPager2(context)

        viewPager2.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            var currentPosition = 0

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                if (slideIndicatorsGroup == null) return

                isToTheRight = position + positionOffset >= currentPosition
                if (positionOffset == 0f) currentPosition = position

                val realPosition = getSelectingIndicatorPosition(isToTheRight)

                val progress =
                    if (scrollState == SCROLL_STATE_SETTLING && Math.abs(currentPagePosition - previousPosition) > 1) {
                        val pageDiff = Math.abs(currentPagePosition - previousPosition)
                        if (isToTheRight) {
                            (position - previousPosition).toFloat() / pageDiff + positionOffset / pageDiff
                        } else {
                            (previousPosition - (position + 1)).toFloat() / pageDiff + (1 - positionOffset) / pageDiff
                        }
                    } else {
                        if (isToTheRight) positionOffset else 1 - positionOffset
                    }

                if (progress == 0f || progress > 1) return

                if (isIndicatorSmart) {
                    if (scrollState != SCROLL_STATE_DRAGGING) return
                    slideIndicatorsGroup?.onIndicatorProgress(realPosition, progress)
                } else {
                    if (scrollState == SCROLL_STATE_DRAGGING) {
                        if (isToTheRight && Math.abs(realPosition - currentPagePosition) == 2 || !isToTheRight && realPosition == currentPagePosition) {
                            //If this happens, it means user is fast scrolling where onPageSelected() is not fast enough
                            //to catch up with the scroll, thus produce wrong position value.
                            return
                        }
                    }
                    slideIndicatorsGroup?.onIndicatorProgress(realPosition, progress)
                }
            }

            override fun onPageScrollStateChanged(state: Int) {
                if (!isIndicatorSmart) {
                    if (scrollState == SCROLL_STATE_SETTLING && state == SCROLL_STATE_DRAGGING) {
                        if (slideIndicatorsGroup != null) {
                            slideIndicatorsGroup?.onIndicatorProgress(
                                getSelectingIndicatorPosition(isToTheRight), 1f
                            )
                        }
                    }
                }
                previousScrollState = scrollState
                scrollState = state

                if (state == SCROLL_STATE_IDLE) {
                    //Below are code to achieve infinite scroll.
                    //We silently and immediately flip the item to the first / last.
                    if (isInfinite) {
                        if (viewPager2.adapter == null) return
                        val itemCount = viewPager2.adapter?.itemCount ?: 0
                        if (itemCount < 2) {
                            return
                        }
                        val index = viewPager2.currentItem
                        if (index == 0) {
                            viewPager2.setCurrentItem(itemCount - 2, false); //Real last item
                        } else if (index == itemCount - 1) {
                            viewPager2.setCurrentItem(1, false) //Real first item
                        }
                    }

                    if (slideIndicatorsGroup != null) {
                        slideIndicatorsGroup?.onIndicatorProgress(getIndicatorPosition(), 1f)
                    }
                }
            }

            override fun onPageSelected(position: Int) {
                previousPosition = currentPagePosition;
                currentPagePosition = position
                if (slideIndicatorsGroup != null) {
                    slideIndicatorsGroup?.onIndicatorPageChange(getIndicatorPosition());
                }
            }
        })
        if (!config.isShowIndicator) {
            slideIndicatorsGroup = SlideIndicatorsGroup(
                context,
                resources.getDrawable(R.drawable.indicator_circle_selected),
                resources.getDrawable(R.drawable.indicator_circle_unselected),
                config.indicatorSize
            )
        }
        if (isInfinite) viewPager2.setCurrentItem(1, false)
    }

    fun setAdapter(adapter: HeroBannerAdapter<T>) {
        if (::viewPager2.isInitialized) {
            this.adapter = adapter
            if (indexOfChild(viewPager2) == -1) {
                viewPager2.layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                addView(viewPager2)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                viewPager2.isNestedScrollingEnabled = false
            }

            adapter.setItemTouchListener(object : View.OnTouchListener {
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    if (event.action == MotionEvent.ACTION_DOWN) {
                        stopTimer()
                    } else if (event.action == MotionEvent.ACTION_CANCEL || event.action == MotionEvent.ACTION_UP) {
                        startTimer()
                    }
                    return false
                }
            })
            viewPager2.adapter = adapter

            if (slideIndicatorsGroup != null && adapter.itemCount > 1) {
                if (indexOfChild(slideIndicatorsGroup) == -1) {
                    addView(slideIndicatorsGroup)
                }
                slideIndicatorsGroup!!.setIndicators(adapter.itemCount)
                slideIndicatorsGroup!!.onIndicatorPageChange(0)
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startTimer()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopTimer()
    }


    private fun startTimer() {
        if (config.interval > 0) {
            stopTimer()
            timer = Timer()
            timer.schedule(SliderTimerTask(), config.interval, config.interval)
        }
    }

    private inner class SliderTimerTask : TimerTask() {

        override fun run() {
            val itemCCount = viewPager2.adapter?.itemCount ?: 0
            if (viewPager2.adapter == null || !isAutoScroll || itemCCount < 2) return
            if (!isInfinite && itemCCount - 1 == currentPagePosition) {
                currentPagePosition = 0
            } else {
                currentPagePosition++
            }
            viewPager2.setCurrentItem(currentPagePosition, true)
        }
    }

    private fun stopTimer() {
        if (::timer.isInitialized) {
            timer.cancel()
            timer.purge()
        }
    }

    fun getSelectingIndicatorPosition(isToTheRight: Boolean): Int {
        if (scrollState == SCROLL_STATE_SETTLING ||
            scrollState == SCROLL_STATE_IDLE ||
            previousScrollState == SCROLL_STATE_SETTLING &&
            scrollState == SCROLL_STATE_DRAGGING
        ) {
            return getIndicatorPosition()
        }
        val adapter = adapter ?: return getIndicatorPosition()

        val delta = if (isToTheRight) 1 else -1
        return if (isInfinite) {
            if (currentPagePosition == 1 && !isToTheRight) { //Special case for first page to last page
                adapter.getLastItemPosition() - 1
            } else if (currentPagePosition == adapter.getLastItemPosition() && isToTheRight) { //Special case for last page to first page
                0
            } else {
                currentPagePosition + delta - 1
            }
        } else {
            currentPagePosition + delta
        }
    }

    private fun getIndicatorPosition(): Int {
        if (!isInfinite) {
            return currentPagePosition
        } else {
            val adapter = adapter ?: return currentPagePosition
            if (viewPager2.adapter is HeroBannerAdapter<*>) return currentPagePosition
            return when (currentPagePosition) {
                0 -> //Dummy last item is selected. Indicator should be at the last one
                    adapter.getListCount() - 1
                adapter.getLastItemPosition() + 1 -> //Dummy first item is selected. Indicator should be at the first one
                    0
                else -> currentPagePosition - 1
            }
        }
    }

    /**
     * A method that helps you integrate a ViewPager Indicator.
     * This method returns the expected count of indicators.
     */
    fun indicatorsCount() = adapter?.getListCount() ?: 0


    /**
     * This function needs to be called if dataSet has changed,
     * in order to reset current selected item and currentPagePosition and autoPageSelectionLock.
     */
    fun reset() {
        currentPagePosition = if (isInfinite) {
            viewPager2.setCurrentItem(1, false)
            1
        } else {
            viewPager2.setCurrentItem(0, false)
            0
        }
    }

    fun setIndicatorSmart(isIndicatorSmart: Boolean) {
        this.isIndicatorSmart = isIndicatorSmart
    }

    interface IndicatorPageChangeListener {
        fun onIndicatorProgress(selectingPosition: Int, progress: Float)

        fun onIndicatorPageChange(newIndicatorPosition: Int)
    }

    fun setInterval(interval: Long) {
        this.interval = interval
        resetAutoScroll()
    }

    private fun resetAutoScroll() {
        stopTimer()
        startTimer()
    }


    companion object {

        private var imageLoadingService: ImageLoadingService? = null

        fun init(imageLoadingService: ImageLoadingService) {
            HeroBanner.imageLoadingService = imageLoadingService
        }

        fun getImageLoadingService(): ImageLoadingService {
            if (imageLoadingService == null) {
                throw IllegalStateException("ImageLoadingService is null, you should call init method first")
            }
            return imageLoadingService!!
        }
    }
}