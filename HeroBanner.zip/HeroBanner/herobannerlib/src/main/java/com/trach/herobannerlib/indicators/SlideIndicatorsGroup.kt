/**
 * Created by laivantrach1190@gmail.com
 * Copyright (c) 2019 . All rights reserved.
 */
package com.trach.herobannerlib.indicators

import android.view.Gravity
import android.content.Context
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.os.Build
import android.graphics.drawable.Drawable
import android.util.Log
import com.trach.herobannerlib.HeroBanner
import com.trach.herobannerlib.R

class SlideIndicatorsGroup(
     context: Context,
    private val selectedSlideIndicator: Drawable?,
    private val unselectedSlideIndicator: Drawable?,
    private val indicatorSize: Int
) : LinearLayout(context), HeroBanner.IndicatorPageChangeListener {

    private var slidesCount: Int = 0
    private val indicatorShapes = ArrayList<HeroIndicator>()

    init {
        orientation = LinearLayout.HORIZONTAL
        val layoutParams =
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layoutParams.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        val margin = resources.getDimensionPixelSize(R.dimen.default_indicator_margin) * 2
        layoutParams.setMargins(0, 0, 0, margin)
        setLayoutParams(layoutParams)
    }

    fun setIndicators(slidesCount: Int) {
        removeAllViews()
        indicatorShapes.clear()
        this.slidesCount = 0
        for (i in 0 until slidesCount) {
            onSlideAdd()
        }
        this.slidesCount = slidesCount
    }

    fun onSlideAdd() {
        this.slidesCount += 1
        addIndicator()
    }

    private fun addIndicator() {
        val indicatorShape: HeroIndicator
        if (selectedSlideIndicator != null && unselectedSlideIndicator != null) {
            indicatorShape = object : HeroIndicator(context, indicatorSize) {
                override fun onCheckedChange(isChecked: Boolean) {
                    if (isChecked) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                            background = selectedSlideIndicator
                        } else {
                            setBackgroundDrawable(selectedSlideIndicator)
                        }
                    } else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                            background = unselectedSlideIndicator
                        } else {
                            setBackgroundDrawable(unselectedSlideIndicator)
                        }
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                indicatorShape.setBackground(unselectedSlideIndicator)
            } else {
                indicatorShape.setBackgroundDrawable(unselectedSlideIndicator)
            }
            indicatorShapes.add(indicatorShape)
            addView(indicatorShape)

        } else {
            indicatorShape = CircleIndicator(context, indicatorSize)
            indicatorShapes.add(indicatorShape)
            addView(indicatorShape)
        }
    }

    override fun onIndicatorProgress(selectingPosition: Int, progress: Float) {

    }

    override fun onIndicatorPageChange(newIndicatorPosition: Int) {
        Log.i(TAG, "onSlideChange: $newIndicatorPosition")
        for (i in indicatorShapes.indices) {
            if (i == newIndicatorPosition) {
                indicatorShapes[i].onCheckedChange(true)
            } else {
                indicatorShapes[i].onCheckedChange(false)
            }
        }
    }

    companion object {
        private val TAG = "SlideIndicatorsGroup"
    }

}