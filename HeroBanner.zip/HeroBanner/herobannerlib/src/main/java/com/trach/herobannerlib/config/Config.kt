/**
 * Created by laivantrach1190@gmail.com
 * Copyright (c) 2019 . All rights reserved.
 */
package com.trach.herobannerlib.config

import android.content.Context
import com.trach.herobannerlib.R
import java.lang.IllegalStateException

data class Config(
    val isAutoScroll: Boolean,
    val isShowIndicator: Boolean,
    val indicatorSize: Int,
    val interval: Long
) {
    class Builder {
        private var isAutoScroll: Boolean = true
        private var isShowIndicator: Boolean = true
        private var indicatorSize: Int = -1
        private var interval: Long = 1500

        fun autoScroll(isAutoScroll: Boolean) = apply { this.isAutoScroll = isAutoScroll }
        fun showIndicator(isShowIndicator: Boolean) = apply { this.isShowIndicator = isShowIndicator }
        fun indicatorSize(indicatorSize: Int) = apply { this.indicatorSize = indicatorSize }
        fun interval(interval: Long) = apply { this.interval = interval }

        fun build(context: Context?): Config {
            if (context == null) {
                throw IllegalStateException("context must be not null")
            }
            if (indicatorSize == -1) {
                indicatorSize = context.resources.getDimensionPixelSize(R.dimen.default_indicator_size)
            }
            return Config(
                isAutoScroll = isAutoScroll,
                isShowIndicator = isShowIndicator,
                indicatorSize = indicatorSize,
                interval = interval
            )
        }
    }
}