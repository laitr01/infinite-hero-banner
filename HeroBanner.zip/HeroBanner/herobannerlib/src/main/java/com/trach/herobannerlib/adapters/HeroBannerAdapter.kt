/**
 * Created by laivantrach1190@gmail.com
 * Copyright (c) 2019 . All rights reserved.
 */
package com.trach.herobannerlib.adapters

import android.view.View
import androidx.recyclerview.widget.RecyclerView

abstract class HeroBannerAdapter<T> : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    protected var itemList = mutableListOf<T>()

    var isInfinite = false
    var canInfinite = true

    fun getListCount() = itemList.size

    fun setItemTouchListener(onTouchListener: View.OnTouchListener) {

    }

    fun getCount(): Int {
        return if (isInfinite && canInfinite) {
            itemList.size + 2
        } else {
            itemList.size
        }
    }

    override fun getItemViewType(listPosition: Int): Int {
        return 0
    }

    private fun getListPosition(position: Int): Int {
        if (!(isInfinite && canInfinite)) return position
        val listPosition: Int
        if (position == 0) {
            listPosition = getCount() - 1 - 2 //First item is a dummy of last item
        } else if (position > getCount() - 2) {
            listPosition = 0 //Last item is a dummy of first item
        } else {
            listPosition = position - 1
        }
        return listPosition
    }

    fun getLastItemPosition(): Int {
        return if (isInfinite) {
            itemList.size
        } else {
            itemList.size - 1
        }
    }
}